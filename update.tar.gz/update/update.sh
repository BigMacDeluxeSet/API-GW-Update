#! /bin/bash
source /etc/profile
set -e
SOURCE="$0"
while [ -h "$SOURCE"  ]; do
    DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /*  ]] && SOURCE="$DIR/$SOURCE"
done
BASEDIR="$( cd -P "$( dirname "$SOURCE"  )" && pwd  )"

source $BASEDIR/config.ini

$DEPLOY_DIR/apictl.sh stop
scp $DEPLOY_DIR/compose/.env.runtime $DEPLOY_DIR/compose/.env.runtime.bak
scp $DEPLOY_DIR/compose/docker-compose.yml $DEPLOY_DIR/compose/docker-compose.yml.bak

scp $BASEDIR/.env.runtime $DEPLOY_DIR/compose/.env.runtime
scp $BASEDIR/docker-compose.yml $DEPLOY_DIR/compose/docker-compose.yml

scp $BASEDIR/.pwd.tmp $BASEDIR/.pwd
sed -i "s/@DB_USER/$DB_USER/g" $BASEDIR/.pwd
sed -i "s/@DB_PWD/$DB_PWD/g" $BASEDIR/.pwd
export CONFIG_ENCRYPT_CONTENT=$(base64 -w 0 $BASEDIR/.pwd)

sed -i "s/@DB_HOST/$DB_HOST/g" $DEPLOY_DIR/compose/.env.runtime 
sed -i "s/@DB_PORT/$DB_PORT/g" $DEPLOY_DIR/compose/.env.runtime 
sed -i "s/@DB_USER/$DB_USER/g" $DEPLOY_DIR/compose/.env.runtime 
sed -i "s/@DB_PWD/$DB_PWD/g" $DEPLOY_DIR/compose/.env.runtime 
sed -i "s/@DB_NAME/$DB_NAME/g" $DEPLOY_DIR/compose/.env.runtime 
sed -i "s/@CONFIG_ENCRYPT_CONTENT/$CONFIG_ENCRYPT_CONTENT/g" $DEPLOY_DIR/compose/.env.runtime 
$DEPLOY_DIR/apictl.sh start

